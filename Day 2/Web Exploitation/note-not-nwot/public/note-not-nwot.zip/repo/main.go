package main

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os"
	"slices"
	"unicode"
)

type NoteData struct {
	Owner   string   `json:"owner"`
	Content string   `json:"content"`
	Access  []string `json:"access"`
}

func isAlphabetic(s string) bool {
	for _, char := range s {
		if !unicode.IsLetter(char) {
			return false
		}
	}
	return true
}

func accessHandler(w http.ResponseWriter, r *http.Request) {
	user := r.URL.Query().Get("user")
	repo := r.URL.Query().Get("repo")
	role := r.URL.Query().Get("role")

	if user == "" || repo == "" || role == "" {
		http.Error(w, "The 'user', 'repo', and 'role' query parameters are required", http.StatusBadRequest)
		return
	}
	if !isAlphabetic(repo) {
		http.Error(w, "'repo' can only contains alphabet", http.StatusBadRequest)
		return
	}

	datas, err := os.ReadFile(fmt.Sprintf("notes/%s.json", repo))
	if err != nil {
		http.Error(w, "repo not found.", http.StatusNotFound)
		return
	}

	var noteData NoteData
	err = json.Unmarshal(datas, &noteData)
	if err != nil {
		http.Error(w, "failed to read repo.", http.StatusInternalServerError)
		return
	}

	if !(user == noteData.Owner || slices.Contains(noteData.Access, user) || role == "admin") {
		http.Error(w, "Access denied", http.StatusForbidden)
		return
	}

	fmt.Fprintf(w, "%s", noteData.Content)
}

func createHandler(w http.ResponseWriter, r *http.Request) {
	// WIP
	http.Error(w, "Still in development", http.StatusBadRequest)
}

func main() {
	http.HandleFunc("/access", accessHandler)
	http.HandleFunc("/create", createHandler)

	fmt.Println("Server is starting on port 8080...")
	if err := http.ListenAndServe(":8080", nil); err != nil {
		log.Fatal("Server error:", err)
	}
}
